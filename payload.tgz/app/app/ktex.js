/* KTEX: plain math text -> LaTeX, with a small e-ink stroke recognizer. */
(function () {
  "use strict";

  // ---------- DOM ----------
  const elInput = document.getElementById("text-input");
  const elLatex = document.getElementById("latex-out");
  const elPretty = document.getElementById("preview-pretty");
  const elStatus = document.getElementById("recog-status");
  const canvas = document.getElementById("ink");
  const ctx = canvas.getContext("2d");

  // ---------- Greek maps ----------
  const GREEK_WORDS = {
    alpha: "\\alpha", beta: "\\beta", gamma: "\\gamma", delta: "\\delta",
    epsilon: "\\epsilon", theta: "\\theta", lambda: "\\lambda", mu: "\\mu",
    pi: "\\pi", rho: "\\rho", sigma: "\\sigma", phi: "\\phi", omega: "\\omega",
    infty: "\\infty", sum: "\\sum", int: "\\int", sqrt: "\\sqrt"
  };
  const GREEK_CHARS = {
    "α": "\\alpha", "β": "\\beta", "γ": "\\gamma", "δ": "\\delta",
    "θ": "\\theta", "π": "\\pi", "λ": "\\lambda", "μ": "\\mu",
    "ρ": "\\rho", "σ": "\\sigma", "φ": "\\phi", "ω": "\\omega",
    "≤": "\\leq", "≥": "\\geq", "≠": "\\neq", "√": "\\sqrt", "∞": "\\infty",
    "·": "\\cdot", "×": "\\cdot", "−": "-", "–": "-"
  };

  // ---------- plain text -> LaTeX ----------
  function protect(s) {
    // shield existing backslashes so word replacements don't eat "alpha" part of \alpha
    return s.replace(/\\/g, "\x01");
  }
  function unprotect(s) {
    return s.replace(/\x01/g, "\\");
  }
  function caretWrap(s) {
    // wrap what follows ^ in braces: ^2 -> ^{2}, ^(x+1) or ^\alpha handled loosely
    s = s.replace(/\^\s*\(([^()]*)\)/g, "^{$1}");
    s = s.replace(/\^\s*(\d+|[A-Za-z])/g, "^{$1}");
    return s;
  }
  function sqrtWrap(s) {
    let prev;
    do {
      prev = s;
      s = s.replace(/sqrt\s*\(([^()]*)\)/g, "\\sqrt{$1}");
      s = s.replace(/\\sqrt\s*\(([^()]*)\)/g, "\\sqrt{$1}");
    } while (s !== prev);
    return s;
  }
  function spaceClean(s) {
    return s.replace(/\s+/g, " ").replace(/\s*([{}()=+\-*/^])\s*/g, "$1").trim();
  }
  function plainToLaTeX(src) {
    if (!src) return "";
    let s = String(src);
    for (const ch in GREEK_CHARS) s = s.split(ch).join(GREEK_CHARS[ch]);
    s = protect(s);
    s = s.replace(/<=/g, "\\leq ");
    s = s.replace(/>=/g, "\\geq ");
    s = s.replace(/!=/g, "\\neq ");
    s = s.replace(/\b([A-Za-z]+)\b/g, function (w) {
      const l = w.toLowerCase();
      if (Object.prototype.hasOwnProperty.call(GREEK_WORDS, l) && w.length > 1) {
        return GREEK_WORDS[l] + " ";
      }
      return w;
    });
    s = sqrtWrap(s);
    s = caretWrap(s);
    s = s.replace(/\*/g, "\\cdot ");
    s = unprotect(s);
    // collapse accidental double backslashes from nested replacements
    s = s.replace(/\\\\/g, "\\");
    return spaceClean(s);
  }

  // ---------- LaTeX -> pretty (unicode-ish) ----------
  // ---------- LaTeX -> DOM (real math look, no HTML injection) ----------
  const SYMBOLS = {
    alpha: "α", beta: "β", gamma: "γ", delta: "δ", epsilon: "ε", varepsilon: "ε",
    zeta: "ζ", eta: "η", theta: "θ", vartheta: "ϑ", iota: "ι", kappa: "κ",
    lambda: "λ", mu: "μ", nu: "ν", xi: "ξ", pi: "π", rho: "ρ", sigma: "σ",
    tau: "τ", upsilon: "υ", phi: "φ", varphi: "ϕ", chi: "χ", psi: "ψ", omega: "ω",
    Gamma: "Γ", Delta: "Δ", Theta: "Θ", Lambda: "Λ", Xi: "Ξ", Pi: "Π",
    Sigma: "Σ", Upsilon: "Υ", Phi: "Φ", Psi: "Ψ", Omega: "Ω",
    cdot: "·", times: "×", div: "÷", pm: "±", mp: "∓", ast: "∗", star: "⋆",
    leq: "≤", le: "≤", geq: "≥", ge: "≥", neq: "≠", ne: "≠", approx: "≈",
    equiv: "≡", sim: "∼", simeq: "≃", propto: "∝",
    infty: "∞", partial: "∂", nabla: "∇", forall: "∀", exists: "∃",
    nexists: "∄", emptyset: "∅", varnothing: "∅", in: "∈", notin: "∉",
    subset: "⊂", supset: "⊃", subseteq: "⊆", supseteq: "⊇", cup: "∪",
    cap: "∩", land: "∧", lor: "∨", neg: "¬", lnot: "¬", therefore: "∴",
    because: "∵", angle: "∠", perp: "⊥", parallel: "∥", sum: "∑",
    prod: "∏", int: "∫", oint: "∮", to: "→", rightarrow: "→", leftarrow: "←",
    leftrightarrow: "↔", Rightarrow: "⇒", Leftarrow: "⇐", Leftrightarrow: "⇔"
  };

  function mkEl(tag, cls) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    return n;
  }
  function addText(parent, s) {
    parent.appendChild(document.createTextNode(s));
  }
  // read a {...} group starting at i; returns [content, indexAfterClose]
  function readGroup(s, i) {
    if (s[i] !== "{") return ["", i];
    let depth = 0;
    for (let j = i; j < s.length; j++) {
      if (s[j] === "{") depth++;
      else if (s[j] === "}") {
        depth--;
        if (depth === 0) return [s.slice(i + 1, j), j + 1];
      }
    }
    return [s.slice(i + 1), s.length];
  }

  function renderLatex(tex, parent) {
    let i = 0;
    while (i < tex.length) {
      const ch = tex[i];
      if (ch === "\\") {
        const m = /^\\([A-Za-z]+)/.exec(tex.slice(i));
        if (m) {
          const cmd = m[1];
          i += m[0].length;
          if (cmd === "frac") {
            const g1 = readGroup(tex, i);
            const g2 = readGroup(tex, g1[1]);
            i = g2[1];
            const f = mkEl("span", "frac");
            const top = mkEl("span", "frac-num");
            renderLatex(g1[0], top);
            const bot = mkEl("span", "frac-den");
            renderLatex(g2[0], bot);
            f.appendChild(top);
            f.appendChild(bot);
            parent.appendChild(f);
            continue;
          }
          if (cmd === "sqrt") {
            const g = readGroup(tex, i);
            i = g[1];
            const s = mkEl("span", "sqrt");
            addText(s, "√");
            const body = mkEl("span", "sqrt-body");
            renderLatex(g[0], body);
            s.appendChild(body);
            parent.appendChild(s);
            continue;
          }
          if (Object.prototype.hasOwnProperty.call(SYMBOLS, cmd)) addText(parent, SYMBOLS[cmd]);
          else addText(parent, cmd); // unknown command: show the name
          continue;
        }
        // escaped character, e.g. \{ or \,
        if (i + 1 < tex.length) {
          addText(parent, tex[i + 1]);
          i += 2;
        } else {
          i++;
        }
        continue;
      }
      if (ch === "^" || ch === "_") {
        i++;
        let inner, ni;
        if (tex[i] === "{") {
          const g = readGroup(tex, i);
          inner = g[0];
          ni = g[1];
        } else {
          inner = tex[i] || "";
          ni = i + 1;
        }
        i = ni;
        const n = mkEl(ch === "^" ? "sup" : "sub");
        renderLatex(inner, n);
        parent.appendChild(n);
        continue;
      }
      if (ch === " ") {
        // collapse runs of spaces, but keep word separation
        while (tex[i] === " ") i++;
        if (i < tex.length && tex[i] !== "}" && tex[i] !== ")" ) addText(parent, " ");
        continue;
      }
      addText(parent, ch);
      i++;
    }
    return parent;
  }

  function render() {
    const src = elInput.value;
    const tex = plainToLaTeX(src);
    elLatex.textContent = tex;
    // rebuild the pretty line with real sup/sub/fraction/radical markup
    while (elPretty.firstChild) elPretty.removeChild(elPretty.firstChild);
    if (tex) renderLatex(tex, elPretty);
    else addText(elPretty, "\u00A0");
  }

  // setRangeText is missing on some older Kindle WebKit builds
  function replaceRange(el, text, start, end) {
    if (typeof el.setRangeText === "function") {
      el.setRangeText(text, start, end, "end");
      return;
    }
    const v = el.value;
    el.value = v.slice(0, start) + text + v.slice(end);
    try {
      const p = start + text.length;
      el.setSelectionRange(p, p);
    } catch (_) {}
  }

  function insertText(t) {
    // Never steal focus here: on a Kindle, focusing the text field pops up the
    // on-screen keyboard, which would cover the ink box after every symbol.
    const focused = document.activeElement === elInput;
    const len = elInput.value.length;
    const start = focused && elInput.selectionStart != null ? elInput.selectionStart : len;
    const end = focused && elInput.selectionEnd != null ? elInput.selectionEnd : len;
    replaceRange(elInput, t, start, end);
    render();
  }

  // ---------- Stroke recognition ----------
  // Gesture buffer: at most a few strokes; recognized as one token or deferred.
  let strokes = [];        // currently inked strokes (array of point arrays)
  let drawing = false;
  let current = null;
  let idleTimer = null;
  let pendingTimer = null; // deferred single-ambiguous-stroke timer
  let lastMinusCtx = null; // {yMid, x0, x1, time} for stacked minus -> '='

  const AMBIGUOUS_SINGLE = new Set(["-", "1"]);

  function strokeLen(pts) {
    let L = 0;
    for (let i = 1; i < pts.length; i++) L += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    return L;
  }
  function bbox(pts) {
    let x0 = pts[0].x, x1 = pts[0].x, y0 = pts[0].y, y1 = pts[0].y;
    for (const p of pts) {
      if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x;
      if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y;
    }
    return { x0, x1, y0, y1, w: x1 - x0, h: y1 - y0 };
  }
  function straightRatio(pts) {
    const d = Math.hypot(pts[pts.length - 1].x - pts[0].x, pts[pts.length - 1].y - pts[0].y);
    const L = strokeLen(pts) || 1;
    return d / L; // 1 = perfectly straight
  }
  function strokeAngle(pts) {
    return Math.atan2(pts[pts.length - 1].y - pts[0].y, pts[pts.length - 1].x - pts[0].x) * 180 / Math.PI;
  }
  function isClosed(pts, bb) {
    const d0 = Math.hypot(pts[0].x - pts[pts.length - 1].x, pts[0].y - pts[pts.length - 1].y);
    return d0 < Math.max(12, 0.3 * Math.min(bb.w, bb.h) + 8);
  }
  function slopeInfo(pts) {
    const bb = bbox(pts);
    const a = strokeAngle(pts);
    const dy = pts[pts.length - 1].y - pts[0].y;
    const dx = pts[pts.length - 1].x - pts[0].x || 0.0001;
    const m = dy / dx;
    return { a, m, bb };
  }
  function classifySingle(pts) {
    if (pts.length < 3) return null;
    const bb = bbox(pts);
    const L = strokeLen(pts);
    if (L < 8) return null;
    const sr = straightRatio(pts);
    const a = strokeAngle(pts);
    const absA = Math.abs(a);
    // closed loop -> 0
    if (isClosed(pts, bb) && L > 1.2 * Math.hypot(pts[0].x - pts[pts.length - 1].x, pts[0].y - pts[pts.length - 1].y) && bb.w > 8 && bb.h > 8) {
      return "0";
    }
    // ^ shape: apex near horizontal middle and higher than both ends
    let minY = pts[0].y, minIdx = 0;
    for (let i = 0; i < pts.length; i++) if (pts[i].y < minY) { minY = pts[i].y; minIdx = i; }
    const frac = minIdx / (pts.length - 1);
    if (frac > 0.25 && frac < 0.75 && bb.h > 10 &&
        pts[0].y > minY + 0.25 * bb.h && pts[pts.length - 1].y > minY + 0.25 * bb.h) {
      return "^";
    }
    if (sr > 0.85) {
      if (absA < 22 || absA > 158) return "-";
      if (absA > 65 && absA < 115) return "1";     // vertical line -> 1 (deferred vs '+')
      if ((a > -75 && a < -15) || (a > 105 && a < 165)) return "/"; // rising stroke on screen = '/'
      return null;
    }
    return null;
  }
  function classifyPair(p1, p2) {
    if (!p1 || !p2 || p1.length < 3 || p2.length < 3) return null;
    const a1 = strokeAngle(p1), a2 = strokeAngle(p2);
    const h1 = Math.abs(a1) < 25 || Math.abs(a1) > 155;
    const h2 = Math.abs(a2) < 25 || Math.abs(a2) > 155;
    const v1 = Math.abs(a1) > 65 && Math.abs(a1) < 115;
    const v2 = Math.abs(a2) > 65 && Math.abs(a2) < 115;
    const b1 = bbox(p1), b2 = bbox(p2);
    const overlapX = Math.min(b1.x1, b2.x1) - Math.max(b1.x0, b2.x0);
    const overlapY = Math.min(b1.y1, b2.y1) - Math.max(b1.y0, b2.y0);
    if (h1 && h2 && overlapX > 0.3 * Math.min(b1.w, b2.w) + 4) {
      const gap = Math.abs((b1.y0 + b1.y1) / 2 - (b2.y0 + b2.y1) / 2);
      if (gap > 0.2 * Math.max(b1.h, b2.h) + 6) return "=";
    }
    if ((h1 && v2) || (v1 && h2)) {
      if (overlapX > -4 && overlapY > -4) return "+";
    }
    // both diagonals, opposite slopes, crossing -> x.
    // Slope is normalised by the stroke's own bounding box, so a hand-drawn
    // cross still reads as a cross in the wide, short ink pad.
    function normSlope(pts) {
      const bb = bbox(pts);
      const dx = pts[pts.length - 1].x - pts[0].x;
      const dy = pts[pts.length - 1].y - pts[0].y;
      if (Math.abs(dx) < 1 || bb.h < 4) return dy < 0 ? -Infinity : Infinity;
      return (dy / bb.h) / (dx / bb.w);
    }
    const m1 = normSlope(p1), m2 = normSlope(p2);
    const diag1 = Math.abs(m1) > 0.3 && Math.abs(m1) < 3.3;
    const diag2 = Math.abs(m2) > 0.3 && Math.abs(m2) < 3.3;
    if (diag1 && diag2 && (m1 * m2 < 0) && overlapX > 0.2 * Math.min(b1.w, b2.w) && overlapY > 0.2 * Math.min(b1.h, b2.h)) {
      return "x";
    }
    return null;
  }

  function setStatus(msg) { elStatus.textContent = msg; }

  function clearInk() {
    strokes = [];
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
  function redraw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#000";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    for (const st of strokes) {
      if (st.length < 2) continue;
      ctx.beginPath();
      ctx.moveTo(st[0].x, st[0].y);
      for (let i = 1; i < st.length; i++) ctx.lineTo(st[i].x, st[i].y);
      ctx.stroke();
    }
  }

  function commitToken(tok, strokesUsed) {
    // '--' stacked -> '='
    if (tok === "-" && lastMinusCtx) {
      const cur = strokesUsed[strokesUsed.length - 1];
      const cbb = bbox(cur);
      const yMid = (cbb.y0 + cbb.y1) / 2;
      const x0 = cbb.x0, x1 = cbb.x1;
      const overlapX = Math.min(lastMinusCtx.x1, x1) - Math.max(lastMinusCtx.x0, x0);
      const gap = Math.abs(yMid - lastMinusCtx.yMid);
      if (Date.now() - lastMinusCtx.time < 1200 && gap > 14 && overlapX > 0.3 * Math.min(lastMinusCtx.x1 - lastMinusCtx.x0, x1 - x0)) {
        // replace the previous '-' we inserted with '='
        const v = elInput.value;
        if (v.endsWith("-")) {
          elInput.value = v.slice(0, -1) + "=";
          render();
          lastMinusCtx = null;
          setStatus("Recognized: =");
          clearInk();
          return;
        }
      }
    }
    insertText(tok);
    if (tok === "-") {
      const st = strokesUsed[strokesUsed.length - 1];
      const cbb = bbox(st);
      lastMinusCtx = { yMid: (cbb.y0 + cbb.y1) / 2, x0: cbb.x0, x1: cbb.x1, time: Date.now() };
    } else {
      lastMinusCtx = null;
    }
    setStatus("Recognized: " + tok);
    clearInk();
  }

  function evaluate() {
    if (strokes.length === 0) return;
    const last2 = strokes.length >= 2 ? [strokes[strokes.length - 2], strokes[strokes.length - 1]] : null;
    if (last2) {
      const pair = classifyPair(last2[0], last2[1]);
      if (pair) {
        commitToken(pair, last2);
        clearPending();
        return;
      }
    }
    const last = strokes[strokes.length - 1];
    const single = classifySingle(last);
    if (single && !AMBIGUOUS_SINGLE.has(single)) {
      commitToken(single, [last]);
      clearPending();
      return;
    }
    if (single && AMBIGUOUS_SINGLE.has(single)) {
      setStatus("Held: '-'/'1' — draw a 2nd stroke for + or =, or pause 1.1s…");
      clearTimeout(pendingTimer);
      pendingTimer = setTimeout(function () {
        if (strokes.length > 0) {
          const s2 = classifySingle(strokes[strokes.length - 1]);
          if (s2) commitToken(s2, [strokes[strokes.length - 1]]);
          else setStatus("No symbol recognized.");
        }
        clearPending();
      }, 1100);
      return;
    }
    setStatus("Not a known symbol. (+= x 0 - 1 / ^)");
  }
  function clearPending() {
    clearTimeout(pendingTimer);
    pendingTimer = null;
  }

  function scheduleEvaluate() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(evaluate, 650);
  }

  // ---------- canvas pointer handling ----------
  function resizeCanvas() {
    const w = canvas.clientWidth || window.innerWidth;
    canvas.width = Math.max(100, w);
    canvas.height = 200;
    redraw();
  }
  window.addEventListener("resize", resizeCanvas);

  function pos(e) {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }
  canvas.addEventListener("pointerdown", function (e) {
    e.preventDefault();
    drawing = true;
    current = [pos(e)];
    clearTimeout(idleTimer);
    try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
  });
  canvas.addEventListener("pointermove", function (e) {
    if (!drawing || !current) return;
    e.preventDefault();
    current.push(pos(e));
    // live ink preview
    ctx.strokeStyle = "#000";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const n = current.length;
    if (n >= 2) {
      ctx.beginPath();
      ctx.moveTo(current[n - 2].x, current[n - 2].y);
      ctx.lineTo(current[n - 1].x, current[n - 1].y);
      ctx.stroke();
    }
  });
  function endStroke(e) {
    if (!drawing || !current) return;
    drawing = false;
    if (current.length > 1) strokes.push(current);
    current = null;
    if (strokes.length > 4) strokes.shift(); // keep buffer bounded
    scheduleEvaluate();
  }
  canvas.addEventListener("pointerup", endStroke);
  canvas.addEventListener("pointercancel", endStroke);

  // ---------- controls ----------
  // Tapping the raw LaTeX selects all of it, so it can be long-press copied on
  // the Kindle (the clipboard API is not available to WAFs).
  elLatex.addEventListener("click", function () {
    try {
      const r = document.createRange();
      r.selectNodeContents(elLatex);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
      setStatus("LaTeX selected - long-press to copy.");
    } catch (_) {
      setStatus("Tap and hold the LaTeX line to select it.");
    }
  });
  document.querySelectorAll(".sym").forEach(function (b) {
    b.addEventListener("click", function () { insertText(b.getAttribute("data-ins")); });
  });
  document.getElementById("btn-clear").addEventListener("click", function () { elInput.value = ""; render(); });
  document.getElementById("btn-back").addEventListener("click", function () {
    const focused = document.activeElement === elInput;
    const s = focused ? elInput.selectionStart : elInput.value.length;
    const e = focused ? elInput.selectionEnd : elInput.value.length;
    if (s != null && e != null && s !== e) replaceRange(elInput, "", s, e);
    else if (s > 0) replaceRange(elInput, "", s - 1, s);
    render();
  });
  document.getElementById("btn-space").addEventListener("click", function () { insertText(" "); });
  document.getElementById("btn-clearink").addEventListener("click", function () { clearInk(); clearPending(); setStatus("Ink cleared."); });
  document.getElementById("btn-undo").addEventListener("click", function () {
    if (strokes.length) { strokes.pop(); redraw(); clearPending(); setStatus("Removed last stroke."); }
  });
  elInput.addEventListener("input", render);

  // init
  resizeCanvas();
  render();
  setStatus("Ready — write symbols or type above.");
})();
