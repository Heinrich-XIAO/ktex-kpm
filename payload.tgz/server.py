#!/usr/bin/env python3
"""KTEX static server: serves the offline web app on localhost.

Stdlib only (works with the Kindle's python3). Disables caching so e-ink
users never stare at a stale bundle, and binds to loopback only.

Usage: server.py [port] [appdir]
"""
import functools
import os
import sys


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8089
    appdir = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "app"
    )
    os.chdir(appdir)

    try:
        from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
    except ImportError:  # very old python3 fallback
        from http.server import SimpleHTTPRequestHandler, HTTPServer as ThreadingHTTPServer

    class NoCacheHandler(SimpleHTTPRequestHandler):
        server_version = "KTEX/0.1.0"

        def end_headers(self):
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
            self.send_header("Pragma", "no-cache")
            super().end_headers()

        def log_message(self, fmt, *args):  # keep logs quiet
            sys.stderr.write("ktex-server: " + (fmt % args) + "\n")

    handler = functools.partial(NoCacheHandler, directory=appdir)
    httpd = ThreadingHTTPServer(("127.0.0.1", port), handler)
    sys.stderr.write("ktex-server: serving %s on 127.0.0.1:%d\n" % (appdir, port))
    httpd.serve_forever()


if __name__ == "__main__":
    main()
