#!/bin/sh
# KTEX launch hook. `kpm launch ktex` runs this from the unpacked package dir.
# It serves the offline web app on localhost and opens the Kindle browser at it.

PORT="8089"
TAG="ktex-server"

# Hooks run with the package dir as cwd, but resolve it explicitly anyway.
PKGDIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
if [ ! -f "$PKGDIR/server.py" ]; then
    PKGDIR="$(pwd)"
fi
APPDIR="$PKGDIR/app"
URL="http://127.0.0.1:$PORT/index.html"

echo "KTEX: starting from $PKGDIR"

# Restart any stale server first.
if command -v pkill >/dev/null 2>&1; then
    pkill -f "[$TAG]" 2>/dev/null
    sleep 1
fi

# Serve the app (stdlib only, no dependencies). Tag the process for pkill.
if command -v python3 >/dev/null 2>&1 && [ -f "$PKGDIR/server.py" ] && [ -d "$APPDIR" ]; then
    python3 "$PKGDIR/server.py" "$PORT" "$APPDIR" >>/tmp/ktex-server.log 2>&1 &
    echo "KTEX: server started (log: /tmp/ktex-server.log)"
    sleep 1
else
    echo "KTEX: ERROR python3 or app/ missing, cannot serve UI."
    exit 1
fi

# Best effort: open the UI in the Kindle browser automatically.
OPENED=""
if command -v lipc-set-prop >/dev/null 2>&1; then
    # Try known browser-open invocations; failures are fine (user can open manually).
    lipc-set-prop com.lab126.appmgrd start "app://com.lab126.browser/?url=$URL" 2>/dev/null && OPENED="yes"
    if [ -z "$OPENED" ]; then
        lipc-set-prop com.lab126.pillow openUrl "$URL" 2>/dev/null && OPENED="yes"
    fi
fi

if [ -n "$OPENED" ]; then
    echo "KTEX: opened in browser."
else
    echo "KTEX: open your Kindle Browser and go to: $URL"
fi

# Also paint the URL on screen when possible so it is visible on e-ink.
if command -v eips >/dev/null 2>&1; then
    eips 0 0 "KTEX running: $URL" 2>/dev/null
fi

echo "KTEX: running at $URL"
exit 0
