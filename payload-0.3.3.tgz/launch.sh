#!/bin/sh
# KTEX launch hook. `kpm launch ktex` runs this from the unpacked package dir.
# It serves the offline web app on localhost and opens the Kindle browser at it.

KTEX_ROOT="${KTEX_ROOT:-/mnt/us}"
PORT="8089"
TAG="ktex-server"

# Resolve our own directory without dirname, which is absent on some minimal
# Kindle environments.
case "$0" in
    */*) PKGDIR="${0%/*}" ;;
    *) PKGDIR="." ;;
esac
PKGDIR="$(cd "$PKGDIR" 2>/dev/null && pwd)"
if [ ! -f "$PKGDIR/server.py" ]; then
    PKGDIR="$(pwd)"
fi
APPDIR="$PKGDIR/app"
URL="http://127.0.0.1:$PORT/index.html"

echo "KTEX: starting from $PKGDIR"

# Restart any stale server first.
if command -v pkill >/dev/null 2>&1; then
    pkill -f "[$TAG]" 2>/dev/null
    sleep 1
fi

# Find python3: on PATH, or a standalone build installed to /mnt/us/py.
# KTEX_PY overrides the search (used by the tests).
PY=""
if [ -n "$KTEX_PY" ] && [ -x "$KTEX_PY" ]; then
    PY="$KTEX_PY"
else
    # Note: /mnt/us is vfat, so python3 may only exist as the versioned
    # python3.12 with no symlink - probe those too, and prefer a real file
    # over a symlink.
    # Note: /mnt/us is vfat, so python3 may only exist as the versioned
    # python3.12 with no symlink - probe those too, and prefer a real file
    # over a symlink. Paths are relative to KTEX_ROOT so the install can be
    # relocated (and tested) off-device.
    for candidate in \
        "$KTEX_ROOT/py/python/bin/python3" \
        "$KTEX_ROOT/py/python/bin/python" \
        "$KTEX_ROOT"/py/python/bin/python3.[0-9]* \
        "$(command -v python3 2>/dev/null)" \
        "$(command -v python 2>/dev/null)"
    do
        if [ -n "$candidate" ] && [ -f "$candidate" ] && [ -x "$candidate" ]; then
            PY="$candidate"
            break
        fi
    done
fi

# Diagnose failures explicitly: on an e-ink screen this is all the feedback
# anyone gets, so say exactly what is missing rather than a generic error.
if [ -z "$PY" ]; then
    echo "KTEX: ERROR no python3 found."
    echo "KTEX:   checked /mnt/us/py/python/bin/python3 and python3 on PATH"
    echo "KTEX:   install it with: curl -sL https://tinyurl.com/28njzahc | sh"
    exit 1
fi
echo "KTEX: using python at $PY"
if [ ! -f "$PKGDIR/server.py" ] || [ ! -d "$APPDIR" ]; then
    echo "KTEX: ERROR app files missing."
    echo "KTEX:   launcher dir: $PKGDIR"
    echo "KTEX:   expected server.py there and an app/ folder"
    echo "KTEX:   contents of $PKGDIR:"
    ls "$PKGDIR" 2>&1 | head -5
    echo "KTEX:   re-run the install command to repair it."
    exit 1
fi

# Also serve over http for other devices on the wifi network (e.g. a laptop).
# The Kindle's own browser cannot use it, so failure here is not fatal.
SERVER_PID=""
"$PY" "$PKGDIR/server.py" "$PORT" "$APPDIR" >>/tmp/ktex-server.log 2>&1 &
SERVER_PID=$!
sleep 1
if kill -0 "$SERVER_PID" 2>/dev/null; then
    echo "KTEX: server started for other devices (log: /tmp/ktex-server.log)"
else
    SERVER_PID=""
    echo "KTEX: note: the optional http server did not start, file:// still works."
fi

# The Kindle browser (armhf, FW >= 5.16.4) refuses to load anything from
# localhost or even the device's own LAN IP - confirmed on MobileRead. The
# app is plain HTML/CSS/JS with no XHR, so file:// is the way to load it.
FILE_URL="file://$APPDIR/index.html"

# Try several ways to get the browser onto the page. lipc-set-prop always
# returns 0 on some builds, so treat a non-empty reply as the only real signal.
OPENED=""
if command -v lipc-set-prop >/dev/null 2>&1; then
    OUT="$(lipc-set-prop com.lab126.pillow openUrl "$FILE_URL" 2>&1)"
    case "$OUT" in
        *rror*|*ailed*|*nvalid*) ;;
        *) OPENED="pillow" ;;
    esac
    # last resort: start the browser itself, in case the intent is rejected
    if [ -z "$OPENED" ]; then
        lipc-set-prop com.lab126.appmgrd start app://com.lab126.browser >/dev/null 2>&1
        OPENED="appmgrd"
    fi
fi

echo "KTEX: open in the browser: $FILE_URL"
[ -n "$OPENED" ] && echo "KTEX: open requested via $OPENED."

# Paint it on the e-ink screen so it can be typed by hand if lipc did nothing.
if command -v eips >/dev/null 2>&1; then
    eips 0 0 "KTEX: $FILE_URL" >/dev/null 2>&1
fi

if [ -n "$SERVER_PID" ]; then
    echo "KTEX: also served at $URL for other devices on your wifi."
fi
exit 0
