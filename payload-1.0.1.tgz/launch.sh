#!/bin/sh
# KTEX native launcher. The binary links against the Kindle's own GTK2 stack
# (from the firmware rootfs), so there is nothing else to set up: no python,
# no web server, no browser.
KTEX_ROOT="${KTEX_ROOT:-/mnt/us}"
APP="$KTEX_ROOT/ktex/ktex-gtk"

[ -x "$APP" ] || { echo "KTEX: binary missing at $APP"; exit 1; }

# Keep the screen awake while writing.
if command -v lipc-set-prop >/dev/null 2>&1; then
    lipc-set-prop com.lab126.powerd preventScreenSaver 1 >/dev/null 2>&1
fi

"$APP" "$@"
STATUS=$?

if command -v lipc-set-prop >/dev/null 2>&1; then
    lipc-set-prop com.lab126.powerd preventScreenSaver 0 >/dev/null 2>&1
fi
exit $STATUS
