#!/bin/sh
# KTEX launch hook. `kpm launch ktex` runs this from the unpacked package dir.
# It serves the offline web app on localhost and opens the Kindle browser at it.

PORT="8089"
TAG="ktex-server"

# Resolve our own directory without dirname, which is absent on some minimal
# Kindle environments.
case "$0" in
    */*) PKGDIR="${0%/*}" ;;
    *) PKGDIR="." ;;
esac
PKGDIR="$(cd "$PKGDIR" 2>/dev/null && pwd)"
if [ ! -f "$PKGDIR/server.py" ]; then
    PKGDIR="$(pwd)"
fi
APPDIR="$PKGDIR/app"
URL="http://127.0.0.1:$PORT/index.html"

echo "KTEX: starting from $PKGDIR"

# Restart any stale server first.
if command -v pkill >/dev/null 2>&1; then
    pkill -f "[$TAG]" 2>/dev/null
    sleep 1
fi

# Find python3: on PATH, or a standalone build installed to /mnt/us/py.
# KTEX_PY overrides the search (used by the tests).
PY=""
if [ -n "$KTEX_PY" ] && [ -x "$KTEX_PY" ]; then
    PY="$KTEX_PY"
else
    for candidate in \
        /mnt/us/py/python/bin/python3 \
        /mnt/us/py/python/bin/python \
        "$(command -v python3 2>/dev/null)" \
        "$(command -v python 2>/dev/null)"
    do
        if [ -n "$candidate" ] && [ -x "$candidate" ]; then
            PY="$candidate"
            break
        fi
    done
fi

# Diagnose failures explicitly: on an e-ink screen this is all the feedback
# anyone gets, so say exactly what is missing rather than a generic error.
if [ -z "$PY" ]; then
    echo "KTEX: ERROR no python3 found."
    echo "KTEX:   checked /mnt/us/py/python/bin/python3 and python3 on PATH"
    echo "KTEX:   install it with: curl -sL https://tinyurl.com/28njzahc | sh"
    exit 1
fi
echo "KTEX: using python at $PY"
if [ ! -f "$PKGDIR/server.py" ] || [ ! -d "$APPDIR" ]; then
    echo "KTEX: ERROR app files missing."
    echo "KTEX:   launcher dir: $PKGDIR"
    echo "KTEX:   expected server.py there and an app/ folder"
    echo "KTEX:   contents of $PKGDIR:"
    ls "$PKGDIR" 2>&1 | head -5
    echo "KTEX:   re-run the install command to repair it."
    exit 1
fi

# Serve the app (stdlib only, no dependencies). Tag the process for pkill.
"$PY" "$PKGDIR/server.py" "$PORT" "$APPDIR" >>/tmp/ktex-server.log 2>&1 &
echo "KTEX: server started (log: /tmp/ktex-server.log)"
sleep 1

# Best effort: open the UI in the Kindle browser automatically.
OPENED=""
if command -v lipc-set-prop >/dev/null 2>&1; then
    # Try known browser-open invocations; failures are fine (user can open manually).
    lipc-set-prop com.lab126.appmgrd start "app://com.lab126.browser/?url=$URL" 2>/dev/null && OPENED="yes"
    if [ -z "$OPENED" ]; then
        lipc-set-prop com.lab126.pillow openUrl "$URL" 2>/dev/null && OPENED="yes"
    fi
fi

if [ -n "$OPENED" ]; then
    echo "KTEX: opened in browser."
else
    echo "KTEX: open your Kindle Browser and go to: $URL"
fi

# Also paint the URL on screen when possible so it is visible on e-ink.
if command -v eips >/dev/null 2>&1; then
    eips 0 0 "KTEX running: $URL" 2>/dev/null
fi

echo "KTEX: running at $URL"
exit 0
